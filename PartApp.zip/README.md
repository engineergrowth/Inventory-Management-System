#INVENTORY MANAGEMENT SYSTEM  
This is a C# desktop app to track products and parts. 
