﻿namespace PartApp
{
    public class Inventory
    {
        
    }
}